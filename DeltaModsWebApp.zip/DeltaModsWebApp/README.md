# DeltaMods WebApp

WebView Android app for:

https://deltamods11.blogspot.com/2026/09/box-sizing-border-box-html-body-margin_01845862358.html

## URL behavior

- `deltamods11.blogspot.com` and other HTTP/HTTPS links stay inside the WebView.
- `profitableratecpmnetwork.com` (including `www` and subdomains) opens in the phone's external browser.
- `tel:`, `mailto:` and other non-HTTP schemes are handed to Android apps when possible.
- Android back button navigates WebView history first.

## Build without Android Studio

This repository includes `.github/workflows/build-apk.yml`.

1. Upload this project to GitHub.
2. Push to the `main` branch, or open GitHub Actions and run **Build DeltaMods APK** manually.
3. Open the completed workflow run.
4. Download the artifact named `DeltaMods-debug-apk`.
5. Extract it to get `app-debug.apk`.
